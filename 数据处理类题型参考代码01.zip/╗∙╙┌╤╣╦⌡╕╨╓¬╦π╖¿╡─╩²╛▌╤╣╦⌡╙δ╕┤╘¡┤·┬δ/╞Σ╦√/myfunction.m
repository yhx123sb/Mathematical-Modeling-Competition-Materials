function [output_args1,args2]=myfunction(input_args1,args2)
    printf(This is a test);
    
function h = falling(t)
global GRAVITY
h = 1/2*GRAVITY*t.^2;